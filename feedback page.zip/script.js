// ========================================
// FIREBASE CONFIGURATION
// ========================================
const firebaseConfig = {
    apiKey: "AIzaSyCMxVbtwf3AOaMIhyZEFhAxCuIgERj9d-o",
    authDomain: "nhps-poll-booth.firebaseapp.com",
    databaseURL: "https://nhps-poll-booth-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "nhps-poll-booth",
    storageBucket: "nhps-poll-booth.firebasestorage.app",
    messagingSenderId: "630600929377",
    appId: "1:630600929377:web:10b27f8dcae9dfd047da20"
};

// Import Firebase modules
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { 
    getAuth, 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword,
    signInWithPopup,
    GoogleAuthProvider,
    signOut,
    onAuthStateChanged,
    updateProfile
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { 
    getDatabase, 
    ref, 
    set, 
    get, 
    push, 
    update,
    remove,
    onValue,
    query,
    orderByChild,
    limitToFirst
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js';

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// Admin password (in production, store this securely)
const ADMIN_PASSWORD = "nhps.voice.2018";

// Global state
let currentUser = null;
let teachers = [];
let currentPair = [];
let selectedTeacher = null;
let votedPairs = [];

// ========================================
// AUTHENTICATION
// ========================================

// Check auth state on page load
onAuthStateChanged(auth, (user) => {
    if (user) {
        currentUser = user;
        initializeUser(user);
        showSection('main');
        showPage('home');
    } else {
        showSection('auth');
    }
});

// Toggle between signup and login
document.getElementById('showLogin').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('signupForm').classList.add('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
});

document.getElementById('showSignup').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('signupForm').classList.remove('hidden');
});

// Sign Up
document.getElementById('signupBtn').addEventListener('click', async () => {
    const name = document.getElementById('signupName').value.trim();
    const email = document.getElementById('signupEmail').value.trim();
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('signupConfirmPassword').value;

    if (!name || !email || !password) {
        alert('Please fill all fields');
        return;
    }

    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }

    if (password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }

    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(userCredential.user, { displayName: name });
        
        // Save user to database with all required fields
        await set(ref(db, 'users/' + userCredential.user.uid), {
            name: name,
            email: email,
            totalVotes: 0,
            votedPairs: [],
            createdAt: new Date().toISOString()
        });

        alert('Account created successfully!');
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Login
document.getElementById('loginBtn').addEventListener('click', async () => {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    if (!email || !password) {
        alert('Please fill all fields');
        return;
    }

    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        
        // Check if user exists in database, if not create entry
        const userRef = ref(db, 'users/' + userCredential.user.uid);
        const snapshot = await get(userRef);
        
        if (!snapshot.exists()) {
            await set(userRef, {
                name: userCredential.user.displayName || userCredential.user.email.split('@')[0],
                email: userCredential.user.email,
                totalVotes: 0,
                votedPairs: [],
                createdAt: new Date().toISOString()
            });
        }
    } catch (error) {
        alert('Login Error: ' + error.message);
        console.error('Login failed:', error);
    }
});

// Google Sign In (Signup)
document.getElementById('googleSignupBtn').addEventListener('click', async () => {
    try {
        const result = await signInWithPopup(auth, googleProvider);
        const user = result.user;
        
        // Check if user exists in database
        const userRef = ref(db, 'users/' + user.uid);
        const snapshot = await get(userRef);
        
        if (!snapshot.exists()) {
            await set(userRef, {
                name: user.displayName,
                email: user.email,
                totalVotes: 0,
                votedPairs: [],
                createdAt: new Date().toISOString()
            });
        }
    } catch (error) {
        alert('Error: ' + error.message);
    }
});

// Google Sign In (Login)
document.getElementById('googleLoginBtn').addEventListener('click', async () => {
    try {
        const result = await signInWithPopup(auth, googleProvider);
        const user = result.user;
        
        // Check if user exists in database
        const userRef = ref(db, 'users/' + user.uid);
        const snapshot = await get(userRef);
        
        if (!snapshot.exists()) {
            await set(userRef, {
                name: user.displayName,
                email: user.email,
                totalVotes: 0,
                votedPairs: [],
                createdAt: new Date().toISOString()
            });
        }
    } catch (error) {
        alert('Google Login Error: ' + error.message);
        console.error('Google login failed:', error);
    }
});

// Initialize user data
async function initializeUser(user) {
    currentUser = user;
    
    // Set user avatar
    const initial = user.displayName ? user.displayName.charAt(0).toUpperCase() : user.email.charAt(0).toUpperCase();
    document.getElementById('userAvatar').textContent = initial;
    
    // Ensure user exists in database
    const userRef = ref(db, 'users/' + user.uid);
    const userSnapshot = await get(userRef);
    
    if (!userSnapshot.exists()) {
        await set(userRef, {
            name: user.displayName || user.email.split('@')[0],
            email: user.email,
            totalVotes: 0,
            votedPairs: [],
            createdAt: new Date().toISOString()
        });
    }
    
    // Load teachers
    await loadTeachers();
    
    // Load voted pairs for this user
    votedPairs = [];
    const votesRef = ref(db, 'votes/' + user.uid);
    const votesSnapshot = await get(votesRef);
    if (votesSnapshot.exists()) {
        votedPairs = Object.values(votesSnapshot.val()).map(v => v.pair);
    }
    
    // Load first voting pair
    loadNextPair();
}

// ========================================
// SECTION & PAGE NAVIGATION
// ========================================

function showSection(sectionName) {
    document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(sectionName + 'Section').classList.add('active');
}

function showPage(pageName) {
    document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
    document.getElementById(pageName + 'Page').classList.add('active');
}

// ========================================
// SIDEBAR NAVIGATION
// ========================================

document.getElementById('menuToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('active');
});

document.getElementById('closeSidebar').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('active');
});

// Sidebar menu navigation
document.querySelectorAll('.sidebar-menu a').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = e.target.getAttribute('data-page');
        
        if (page === 'admin') {
            showAdminModal();
        } else {
            showPage(page);
            document.getElementById('sidebar').classList.remove('active');
            
            // Load page-specific data
            if (page === 'rankings') loadRankings();
            if (page === 'comments') loadComments();
            if (page === 'profile') loadProfile();
        }
    });
});

// User avatar click
document.getElementById('userAvatar').addEventListener('click', () => {
    showPage('profile');
    loadProfile();
});

// ========================================
// VOTING SYSTEM
// ========================================

async function loadTeachers() {
    const teachersRef = ref(db, 'teachers');
    const snapshot = await get(teachersRef);
    
    if (snapshot.exists()) {
        teachers = Object.entries(snapshot.val()).map(([id, data]) => ({
            id,
            ...data
        }));
    } else {
        teachers = [];
    }
}

function loadNextPair() {
    if (teachers.length < 2) {
        document.querySelector('.voting-container').innerHTML = '<p class="loading">Please add at least 2 teachers from Admin Panel to start voting</p>';
        return;
    }

    // Find a random pair that hasn't been voted on
    let attempts = 0;
    let pair;
    
    do {
        const shuffled = [...teachers].sort(() => Math.random() - 0.5);
        pair = [shuffled[0], shuffled[1]];
        const pairKey = [pair[0].id, pair[1].id].sort().join('-');
        
        if (!votedPairs.includes(pairKey)) {
            currentPair = pair;
            displayPair(pair);
            return;
        }
        
        attempts++;
    } while (attempts < 50);

    // If all pairs voted, reset
    if (attempts >= 50) {
        votedPairs = [];
        loadNextPair();
    }
}

function displayPair(pair) {
    document.getElementById('teacher1Img').src = pair[0].photo;
    document.getElementById('teacher1Name').textContent = pair[0].name;
    document.getElementById('teacher1Subject').textContent = pair[0].subject;
    
    document.getElementById('teacher2Img').src = pair[1].photo;
    document.getElementById('teacher2Name').textContent = pair[1].name;
    document.getElementById('teacher2Subject').textContent = pair[1].subject;
    
    selectedTeacher = null;
    document.getElementById('selectionText').textContent = '';
    document.getElementById('submitVoteBtn').disabled = true;
    
    document.getElementById('teacher1Card').classList.remove('selected');
    document.getElementById('teacher2Card').classList.remove('selected');
}

// Teacher card selection
document.getElementById('teacher1Card').addEventListener('click', () => {
    selectTeacher(0);
});

document.getElementById('teacher2Card').addEventListener('click', () => {
    selectTeacher(1);
});

function selectTeacher(index) {
    selectedTeacher = currentPair[index];
    
    document.getElementById('teacher1Card').classList.remove('selected');
    document.getElementById('teacher2Card').classList.remove('selected');
    
    if (index === 0) {
        document.getElementById('teacher1Card').classList.add('selected');
    } else {
        document.getElementById('teacher2Card').classList.add('selected');
    }
    
    document.getElementById('selectionText').textContent = `You selected ${selectedTeacher.name}!`;
    document.getElementById('submitVoteBtn').disabled = false;
}

// Submit vote
document.getElementById('submitVoteBtn').addEventListener('click', async () => {
    if (!selectedTeacher || !currentUser) return;
    
    try {
        // Create pair key
        const pairKey = [currentPair[0].id, currentPair[1].id].sort().join('-');
        
        // Save vote
        const voteRef = push(ref(db, 'votes/' + currentUser.uid));
        await set(voteRef, {
            teacherId: selectedTeacher.id,
            teacherName: selectedTeacher.name,
            pair: pairKey,
            timestamp: new Date().toISOString()
        });
        
        // Update teacher votes
        const teacherRef = ref(db, 'teachers/' + selectedTeacher.id);
        const teacherSnapshot = await get(teacherRef);
        if (teacherSnapshot.exists()) {
            const currentVotes = teacherSnapshot.val().votes || 0;
            await update(teacherRef, { votes: currentVotes + 1 });
        }
        
        // Update user total votes
        const userRef = ref(db, 'users/' + currentUser.uid);
        const userSnapshot = await get(userRef);
        
        if (userSnapshot.exists()) {
            const userVotes = userSnapshot.val().totalVotes || 0;
            await update(userRef, { totalVotes: userVotes + 1 });
        } else {
            // If user doesn't exist in database, create entry
            await set(userRef, {
                name: currentUser.displayName || 'User',
                email: currentUser.email,
                totalVotes: 1,
                votedPairs: [],
                createdAt: new Date().toISOString()
            });
        }
        
        // Add to voted pairs
        votedPairs.push(pairKey);
        
        // Reload teachers to get updated votes
        await loadTeachers();
        
        // Show success and load next pair
        document.querySelector('.voting-area').classList.add('fade-in');
        setTimeout(() => {
            document.querySelector('.voting-area').classList.remove('fade-in');
            loadNextPair();
        }, 500);
        
    } catch (error) {
        alert('Error submitting vote: ' + error.message);
        console.error('Vote error:', error);
    }
});

// ========================================
// RANKINGS PAGE
// ========================================

async function loadRankings() {
    const rankingsList = document.getElementById('rankingsList');
    rankingsList.innerHTML = '<p class="loading">Loading rankings</p>';
    
    await loadTeachers();
    
    // Sort teachers by votes
    const sorted = [...teachers].sort((a, b) => (b.votes || 0) - (a.votes || 0));
    
    const totalVotes = sorted.reduce((sum, t) => sum + (t.votes || 0), 0);
    document.getElementById('totalVotesText').textContent = `Total Votes: ${totalVotes}`;
    
    rankingsList.innerHTML = '';
    
    sorted.forEach((teacher, index) => {
        const rank = index + 1;
        const item = document.createElement('div');
        item.className = 'rank-item' + (rank <= 3 ? ' top3' : '');
        
        const medal = rank === 1 ? '🥇' : rank === 2 ? '🥈' : rank === 3 ? '🥉' : '';
        
        item.innerHTML = `
            <div class="rank-number">${medal} #${rank}</div>
            <img src="${teacher.photo}" alt="${teacher.name}">
            <div class="rank-info">
                <h3>${teacher.name}</h3>
                <p>${teacher.subject}</p>
            </div>
            <div class="rank-score">${teacher.votes || 0}</div>
        `;
        
        rankingsList.appendChild(item);
    });
}

// ========================================
// COMMENTS PAGE
// ========================================

document.getElementById('postCommentBtn').addEventListener('click', async () => {
    const text = document.getElementById('commentText').value.trim();
    
    if (!text) {
        alert('Please write a comment');
        return;
    }
    
    if (!currentUser) {
        alert('Please login first');
        return;
    }
    
    try {
        const commentRef = push(ref(db, 'comments'));
        await set(commentRef, {
            text: text,
            user: currentUser.email,
            userName: currentUser.displayName || 'Anonymous',
            timestamp: new Date().toISOString()
        });
        
        document.getElementById('commentText').value = '';
        loadComments();
        alert('Comment posted successfully!');
    } catch (error) {
        alert('Error posting comment: ' + error.message);
    }
});

async function loadComments() {
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '<p class="loading">Loading comments</p>';
    
    const commentsRef = ref(db, 'comments');
    const snapshot = await get(commentsRef);
    
    commentsList.innerHTML = '';
    
    if (snapshot.exists()) {
        const comments = Object.entries(snapshot.val())
            .map(([id, data]) => ({ id, ...data }))
            .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
        
        comments.forEach(comment => {
            const item = document.createElement('div');
            item.className = 'comment-item';
            
            const date = new Date(comment.timestamp).toLocaleDateString();
            const agreeCount = comment.agreeCount || 0;
            const agreedUsers = comment.agreedUsers || {};
            const hasAgreed = currentUser && agreedUsers[currentUser.uid];
            
            item.innerHTML = `
                <div class="comment-header">
                    <span>Anonymous Student</span>
                    <span>${date}</span>
                </div>
                <div class="comment-text">${comment.text}</div>
                <div class="comment-actions">
                    <button class="agree-btn ${hasAgreed ? 'agreed' : ''}" onclick="toggleAgree('${comment.id}')">
                        <span>👍</span>
                        <span>Agree (${agreeCount})</span>
                    </button>
                </div>
            `;
            
            commentsList.appendChild(item);
        });
    } else {
        commentsList.innerHTML = '<p class="loading">No comments yet</p>';
    }
}

// Toggle Agree Function (Instagram Style)
window.toggleAgree = async (commentId) => {
    if (!currentUser) {
        alert('Please login first');
        return;
    }
    
    try {
        const commentRef = ref(db, 'comments/' + commentId);
        const snapshot = await get(commentRef);
        
        if (!snapshot.exists()) return;
        
        const comment = snapshot.val();
        const agreedUsers = comment.agreedUsers || {};
        const agreeCount = comment.agreeCount || 0;
        
        if (agreedUsers[currentUser.uid]) {
            // Remove agree
            delete agreedUsers[currentUser.uid];
            await update(commentRef, {
                agreedUsers: agreedUsers,
                agreeCount: Math.max(0, agreeCount - 1)
            });
        } else {
            // Add agree
            agreedUsers[currentUser.uid] = true;
            await update(commentRef, {
                agreedUsers: agreedUsers,
                agreeCount: agreeCount + 1
            });
        }
        
        // Reload comments to show updated count
        loadComments();
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

// ========================================
// PROFILE PAGE
// ========================================

async function loadProfile() {
    if (!currentUser) return;
    
    const initial = currentUser.displayName ? currentUser.displayName.charAt(0).toUpperCase() : currentUser.email.charAt(0).toUpperCase();
    document.getElementById('profileAvatar').textContent = initial;
    document.getElementById('profileName').textContent = currentUser.displayName || 'User';
    document.getElementById('profileEmail').textContent = currentUser.email;
    
    const userRef = ref(db, 'users/' + currentUser.uid);
    const snapshot = await get(userRef);
    
    if (snapshot.exists()) {
        const userData = snapshot.val();
        document.getElementById('profileVotes').textContent = `Total Votes: ${userData.totalVotes || 0}`;
    } else {
        // If user data doesn't exist, create it
        await set(userRef, {
            name: currentUser.displayName || currentUser.email.split('@')[0],
            email: currentUser.email,
            totalVotes: 0,
            votedPairs: [],
            createdAt: new Date().toISOString()
        });
        document.getElementById('profileVotes').textContent = 'Total Votes: 0';
    }
}

// ========================================
// LOGOUT
// ========================================

let logoutCallback = null;

document.getElementById('logoutBtn').addEventListener('click', () => {
    showLogoutModal();
});

document.getElementById('sidebarLogout').addEventListener('click', (e) => {
    e.preventDefault();
    showLogoutModal();
});

function showLogoutModal() {
    document.getElementById('logoutModal').classList.add('active');
}

document.getElementById('confirmLogout').addEventListener('click', async () => {
    try {
        await signOut(auth);
        document.getElementById('logoutModal').classList.remove('active');
        document.getElementById('sidebar').classList.remove('active');
        showSection('auth');
    } catch (error) {
        alert('Error logging out: ' + error.message);
    }
});

document.getElementById('cancelLogout').addEventListener('click', () => {
    document.getElementById('logoutModal').classList.remove('active');
});

// ========================================
// ADMIN PANEL
// ========================================

function showAdminModal() {
    document.getElementById('adminModal').classList.add('active');
    document.getElementById('adminPassword').value = '';
}

document.getElementById('confirmAdmin').addEventListener('click', () => {
    const password = document.getElementById('adminPassword').value;
    
    if (password === ADMIN_PASSWORD) {
        document.getElementById('adminModal').classList.remove('active');
        document.getElementById('sidebar').classList.remove('active');
        showPage('admin');
        loadAdminPanel();
    } else {
        alert('Incorrect password');
    }
});

document.getElementById('cancelAdmin').addEventListener('click', () => {
    document.getElementById('adminModal').classList.remove('active');
});

// Admin tabs
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        
        const tab = e.target.getAttribute('data-tab');
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        document.getElementById(tab + 'Tab').classList.add('active');
        
        if (tab === 'users') loadAdminUsers();
        if (tab === 'teachers') loadAdminTeachers();
    });
});

// Base64 Photo Upload Handler
let teacherPhotoBase64 = '';

document.getElementById('teacherPhotoFile').addEventListener('change', function(e) {
    const file = e.target.files[0];
    
    if (!file) return;
    
    // Check file size (max 500KB for free Firebase)
    if (file.size > 500000) {
        alert('Photo size should be less than 500KB!');
        document.getElementById('photoStatus').textContent = '❌ File too large!';
        document.getElementById('photoStatus').style.color = '#f4212e';
        return;
    }
    
    // Check file type
    if (!file.type.startsWith('image/')) {
        alert('Please select an image file!');
        return;
    }
    
    document.getElementById('photoStatus').textContent = '⏳ Converting to Base64...';
    document.getElementById('photoStatus').style.color = '#1d9bf0';
    
    const reader = new FileReader();
    
    reader.onload = function(event) {
        teacherPhotoBase64 = event.target.result;
        
        // Show preview
        const preview = document.getElementById('photoPreview');
        preview.src = teacherPhotoBase64;
        preview.style.display = 'block';
        
        document.getElementById('photoStatus').textContent = '✅ Photo ready to upload!';
        document.getElementById('photoStatus').style.color = '#4ec963';
    };
    
    reader.onerror = function() {
        alert('Error reading file!');
        document.getElementById('photoStatus').textContent = '❌ Error reading file!';
        document.getElementById('photoStatus').style.color = '#f4212e';
    };
    
    reader.readAsDataURL(file);
});

// Trigger file input when label is clicked
document.querySelector('.photo-upload-label').addEventListener('click', () => {
    document.getElementById('teacherPhotoFile').click();
});

async function loadAdminPanel() {
    loadAdminUsers();
    loadAdminTeachers();
}

async function loadAdminUsers() {
    const usersList = document.getElementById('usersList');
    usersList.innerHTML = '<p class="loading">Loading users</p>';
    
    const usersRef = ref(db, 'users');
    const snapshot = await get(usersRef);
    
    usersList.innerHTML = '';
    
    if (snapshot.exists()) {
        const users = Object.entries(snapshot.val()).map(([id, data]) => ({ id, ...data }));
        
        for (const user of users) {
            // Get user comments
            const commentsRef = ref(db, 'comments');
            const commentsSnapshot = await get(commentsRef);
            let userComments = [];
            
            if (commentsSnapshot.exists()) {
                userComments = Object.entries(commentsSnapshot.val())
                    .filter(([_, c]) => c.user === user.email)
                    .map(([id, c]) => ({ id, ...c }));
            }
            
            const item = document.createElement('div');
            item.className = 'user-item';
            item.innerHTML = `
                <div>
                    <h4>${user.name || 'User'}</h4>
                    <p>${user.email}</p>
                    <p>Votes: ${user.totalVotes || 0}</p>
                    <p>Comments: ${userComments.length}</p>
                </div>
                <button class="btn-danger" onclick="deleteUser('${user.id}')">Delete</button>
            `;
            
            usersList.appendChild(item);
        }
    } else {
        usersList.innerHTML = '<p class="loading">No users found</p>';
    }
}

async function loadAdminTeachers() {
    await loadTeachers();
    
    const teachersList = document.getElementById('teachersList');
    const totalVotes = teachers.reduce((sum, t) => sum + (t.votes || 0), 0);
    
    document.getElementById('teacherStats').textContent = `Total Teachers: ${teachers.length} | Total Votes: ${totalVotes}`;
    
    teachersList.innerHTML = '';
    
    teachers.forEach(teacher => {
        const item = document.createElement('div');
        item.className = 'teacher-item';
        item.innerHTML = `
            <div>
                <h4>${teacher.name}</h4>
                <p>${teacher.subject} - ${teacher.votes || 0} votes</p>
            </div>
            <button class="btn-danger" onclick="deleteTeacher('${teacher.id}')">Delete</button>
        `;
        
        teachersList.appendChild(item);
    });
}

document.getElementById('addTeacherBtn').addEventListener('click', async () => {
    const name = document.getElementById('teacherName').value.trim();
    const subject = document.getElementById('teacherSubject').value.trim();
    
    if (!name || !subject) {
        alert('Please fill name and subject!');
        return;
    }
    
    if (!teacherPhotoBase64) {
        alert('Please upload a photo!');
        return;
    }
    
    try {
        const newTeacherRef = push(ref(db, 'teachers'));
        await set(newTeacherRef, {
            name,
            subject,
            photo: teacherPhotoBase64,
            votes: 0,
            createdAt: new Date().toISOString()
        });
        
        // Clear form
        document.getElementById('teacherName').value = '';
        document.getElementById('teacherSubject').value = '';
        document.getElementById('teacherPhotoFile').value = '';
        document.getElementById('photoPreview').style.display = 'none';
        document.getElementById('photoStatus').textContent = '';
        teacherPhotoBase64 = '';
        
        loadAdminTeachers();
        loadTeachers();
        alert('Teacher added successfully!');
    } catch (error) {
        alert('Error adding teacher: ' + error.message);
    }
});

// Global functions for delete buttons (called from HTML)
window.deleteTeacher = async (id) => {
    if (!confirm('Delete this teacher?')) return;
    
    try {
        await remove(ref(db, 'teachers/' + id));
        loadAdminTeachers();
        loadTeachers();
        alert('Teacher deleted');
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

window.deleteUser = async (id) => {
    if (!confirm('Delete this user?')) return;
    
    try {
        await remove(ref(db, 'users/' + id));
        loadAdminUsers();
        alert('User deleted');
    } catch (error) {
        alert('Error: ' + error.message);
    }
};

// ========================================
// INITIALIZE
// ========================================

console.log('NHPS Poll Booth initialized');
console.log('Remember to add your Firebase config!');